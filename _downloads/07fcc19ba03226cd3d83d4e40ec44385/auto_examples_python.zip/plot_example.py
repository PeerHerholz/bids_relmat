# -*- coding: utf-8 -*-
"""
bids_relmat example
=====================================
This example demonstrates how to use :mod:`bids_relmat`.
"""
